export default Object.freeze({
  DANGEROUS: 2,
  SUSPICIOUS: 1,
  SAFE: 0
});
