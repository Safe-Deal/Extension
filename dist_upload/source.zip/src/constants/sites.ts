export const siteNames = Object.freeze({
  ALI_EXPRESS: "aliexpress",
  EBAY: "ebay",
  AMAZON: "amazon",
  WALMART: "walmart",
  ALIBABA: "alibaba"
});

export const SAFE_DEAL_OFF = "SAFE-DEAL-OFF-ON-THIS-PAGE";
