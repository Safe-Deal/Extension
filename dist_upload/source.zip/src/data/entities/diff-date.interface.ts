export interface IDiffDate {
  yearDiff: number;
  monthDiff: number;
  dayDiff: number;
  roundYearDiff: number;
}
