export const PROCESSING_UPDATE_INTERVAL = 200;
export const Z_INDEX_MAX = 2147483647;
export const Z_INDEX_TOP = 2147483645;
export const DEFAULT_BG_COLOR = "#fff";
