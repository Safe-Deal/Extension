export const API_URL = "https://api.joinsafedeal.com";
export const LOCALHOST_API_URL = "http://localhost:80";
