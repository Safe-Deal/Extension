export const PRICING_ITEM_DETAILS = "Pricing Item Details";
