export default Object.freeze({
  COMMERCE: Symbol("COMMERCE"),
  MAJOR_COMMERCE: Symbol("MAJOR_COMMERCE"),
  NOT_COMMERCE: Symbol("NOT_COMMERCE")
});
