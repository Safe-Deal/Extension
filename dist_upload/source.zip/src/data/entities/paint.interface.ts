export interface IPaint {
  draw: ({}: any) => Element;
}
