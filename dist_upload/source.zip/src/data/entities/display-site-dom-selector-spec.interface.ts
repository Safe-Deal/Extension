export interface IDisplaySiteDomSelectorSpec {
  imageSel?: string;
  wholesalePageItemListSel?: string;
  wholesalePageProductListSel?: string;
  wholesalePagePriceSel?: string;

  itemPageProductSel?: string;
  itemPageProductInfoActionsSel?: string;
  itemLoaderProductElSel?: string;
}
