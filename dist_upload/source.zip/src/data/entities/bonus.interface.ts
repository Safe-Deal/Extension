export interface IBonusRule {
  isBonusRule: boolean;
  value: number;
}
