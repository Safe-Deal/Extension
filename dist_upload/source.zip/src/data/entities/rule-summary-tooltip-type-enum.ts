export enum RuleSummaryTooltipType {
  SAFE = "SAFE",
  UNSAFE = "UNSAFE"
}
