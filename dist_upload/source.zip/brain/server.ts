/* eslint-disable import/order */
/* eslint-disable import/first */
import { ServerLogger, initSentry, setupSentry } from "./utils/logging";

initSentry();

import express from "express";
import { apiAuth } from "./middleware/auth";
import { registerFetchProxy } from "./middleware/fetch-proxy";
import { processProduct } from "./services/brain-worker";
import { initProcessProductDataFromUrl, serializeToJson } from "./utils/utils";
import { scrape } from "./services/scrapingService";
import { printVersion } from "./utils/monitoring";

const { PORT = 80 } = process.env;
const INTERNAL_NETWORK_PORT = 8081;

registerFetchProxy();
const app = express();
setupSentry(app);

app.get("/think", apiAuth(), async (req, res) => {
  const targetUrl = req.query.url as string;
  const lang = req.query.lang as string;
  const regenerate = req.query.regenerate !== undefined;

  if (!targetUrl) {
    return res.status(400).send("URL parameter is required");
  }
  const productRequest = initProcessProductDataFromUrl(targetUrl, lang, regenerate);
  const response = await processProduct(productRequest);
  res.setHeader("Content-Type", "application/json");
  res.end(serializeToJson(response));
});

app.get("/extract", apiAuth(), async (req, res) => {
  const url = req.query.url as string;
  const waitForCssSelector = req.query.waitForCssSelector as string;
  const regenerate = req.query.regenerate !== undefined;
  const result = await scrape({ url, waitForCssSelector, regenerate });

  if (result.status !== 200) {
    ServerLogger.error(`Extract:: Failed to extract data from ${url}`);
    res.status(result.status).send("Failed to extract data");
  } else {
    ServerLogger.green(`Extract:: Successfully extracted data from ${url}`);
    res.setHeader("Content-Type", "text/html");
    res.end(result.result);
  }
});

app.get("/", async (req, res) => {
  res.setHeader("Content-Type", "text/plain");
  res.send("Brain server is running");
});

printVersion();
app.listen(PORT, () => {
  ServerLogger.green(`Brain Server listening at port:${PORT} (IPv4)`);
});

app.listen(INTERNAL_NETWORK_PORT, "::", () => {
  ServerLogger.log(`\x1b[35mBrain Server listening at port:${INTERNAL_NETWORK_PORT} (IPv6)\x1b[0m`);
});
