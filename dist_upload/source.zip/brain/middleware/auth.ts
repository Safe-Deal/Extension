const API_KEY = "EsAwC9Fq4EhvhrQnVQxrqMN23GJs1CiwpseZapTlf5M-brn";

export const apiAuth = () => (req, res, next) => {
  if (req.headers["api-key"] !== API_KEY) {
    res.status(403).send("Forbidden");
  } else {
    next();
  }
};
