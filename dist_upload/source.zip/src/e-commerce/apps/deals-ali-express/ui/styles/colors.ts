export const colors = {
  primary: "#00A660",
  floatButtonColor: "#0e2439",
  white: "#FFFFFF",
  red: "#f93852",
  orange: "#D97706"
};
