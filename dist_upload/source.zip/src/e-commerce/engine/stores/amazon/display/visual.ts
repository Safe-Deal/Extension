export const GOOD_BORDER = "rgba(16, 186, 145, 0.40)";
export const GOOD_BG = "rgba(16, 186, 145, 1)";

export const BAD_BORDER = "rgba(203, 3, 37, 0.40)";
export const BAD_BG = "rgba(203, 3, 37, 1)";

export const DOUBTFUL_BORDER = "rgba(255, 183, 67, 0.7)";
export const DOUBTFUL_BG = "rgba(255, 166, 22, 1)";

export const INSUFFICIENT_DATA_BORDER = "rgba(184, 179, 169, 0.7)";
export const INSUFFICIENT_DATA_BG = "rgba(199, 195, 187, 1)";
