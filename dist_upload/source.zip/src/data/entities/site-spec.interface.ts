export interface ISiteSpec {
  url?: string;
  domain?: string;
  domainURL?: string;
  pathName?: string;
  queryParams?: string;
  dom?: any;
}
