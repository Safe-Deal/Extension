export default Object.freeze({
  WALMART_SOLD_SHIP_ITEM_DETAILS: "Walmart Sold Ship Item Details",
  WALMART_SOLD_SHIP_WHOLESALE_GALLERY: "Walmart Sold Ship Wholesale Gallery",
  WALMART_SOLD_SHIP_WHOLESALE_LIST: "Walmart Sold Ship Wholesale List",

  PRODUCT_FEEDBACK_ITEM_DETAILS: "Walmart Product Feedback Item Details",
  PRODUCT_FEEDBACK_WHOLESALE_GALLERY: "Walmart Product Feedback Wholesale Gallery",
  PRODUCT_FEEDBACK_WHOLESALE_LIST: "Walmart Product Feedback Wholesale List",

  PRO_SELLER_ITEM_DETAILS: "Walmart Pro Seller Item Details",
  PRO_SELLER_WHOLESALE_GALLERY: "Walmart Wholesale Gallery",
  PRO_SELLER_WHOLESALE_LIST: "Walmart Wholesale List"
});
