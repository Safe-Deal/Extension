export const getUrlByAsin = (domain, asin) => `https://${domain}/ip/${asin}`;
