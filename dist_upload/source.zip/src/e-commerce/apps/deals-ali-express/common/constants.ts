export const ALIEXPRESS_CAMPAIGN_URL = "/gcp/";
