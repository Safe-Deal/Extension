export const dataGridStyles = {
  boxShadow: 2,
  "& .MuiDataGrid-row": {},
  "& .MuiTablePagination-root": {},
  "& .MuiButtonBase-root": {},
  "& .MuiDataGrid-footerContainer": {
    display: "none"
  }
};
