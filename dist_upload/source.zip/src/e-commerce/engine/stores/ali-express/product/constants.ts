export const EMPTY_PRODUCT = {
  productPrice: null,
  productRatingAverage: null,
  productRatingsAmount: null,
  productPurchases: null,
  storeOpenTime: null,
  storePositiveRate: null,
  storeIsTopRated: null,
  json: null
};
